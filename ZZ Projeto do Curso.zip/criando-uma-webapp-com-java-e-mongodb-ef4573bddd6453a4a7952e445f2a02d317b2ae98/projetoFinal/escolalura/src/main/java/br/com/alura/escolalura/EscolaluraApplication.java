package br.com.alura.escolalura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EscolaluraApplication {

	public static void main(String[] args) {
		SpringApplication.run(EscolaluraApplication.class, args);
	}
}
